#pragma once


class Packets{
  //private:
    //static const String START_BIT;
    //static const String STOP_BIT;
  
  public:
    static void sendPacket(const String& data);
};
